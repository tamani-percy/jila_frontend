interface RiderResponse {
    id: number,
    name: string,
    nrc: string,
    email: string,
    phoneNumber: string
}

interface RiderRequest {

}