export const DriverStatus: Record<string, string>[] = [
    {
        name: "ACTIVE",
        value: "ACTIVE"

    },
    {
        name: "INACTIVE",
        value: "INACTIVE"
    }, {

        name: "BANNED",
        value: "BANNED"

    }
]