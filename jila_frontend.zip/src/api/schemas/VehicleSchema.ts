export const VehicleMake: Record<string, string>[] = [
    {
        name: "TOYOTA",
        value: "TOYOTA"

    },
    {
        name: "ISUZU",
        value: "ISUZU"
    },
    {
        name: "MAZDA",
        value: "MAZDA"
    },
    {
        name: "SUZUKI",
        value: "SUZUKI"
    },
    {
        name: "MERCEDES",
        value: "MERCEDES"
    },
    {
        name: "FORD",
        value: "FORD"
    },
    {
        name: "SUBARU",
        value: "SUBARU"
    },
    {
        name: "GWM",
        value: "GWM"
    },
    {
        name: "GMC",
        value: "GMC"
    },
    {
        name: "HYUNDAI",
        value: "HYUNDAI"
    },
    {
        name: "KIA",
        value: "KIA"
    },
    {
        name: "HONDA",
        value: "HONDA"
    }
]