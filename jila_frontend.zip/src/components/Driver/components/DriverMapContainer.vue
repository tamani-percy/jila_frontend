<script setup lang="ts">
import {nextTick, onBeforeUnmount, onMounted, ref, watch} from "vue"
import * as L from "leaflet"
import "leaflet/dist/leaflet.css"

const props = defineProps<{
  rideRequest: RideRequestResponse
}>()

const map = ref<L.Map | null>(null)
const driverMapContainer = ref<HTMLElement | null>(null)
const initializeMap = () => {
  if (!props.rideRequest || !driverMapContainer.value) return

  const [pickupLat, pickupLon] =
      props.rideRequest.pickupLocation.split(",").map(Number)

  const [dropoffLat, dropoffLon] =
      props.rideRequest.dropOffLocation.split(",").map(Number)

  if (map.value) {
    map.value.remove()
    map.value = null
  }

  map.value = L.map(driverMapContainer.value).setView([pickupLat, pickupLon], 13)

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap contributors",
    className: "grayscale"
  }).addTo(map.value)

  const mapPinIcon = L.icon({
    iconUrl: '/images/svgs/map-pin.svg',
    iconSize: [20, 20],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32]
  })

  // Pickup marker
  L.marker([pickupLat, pickupLon], {icon: mapPinIcon})
      .addTo(map.value)
      .bindPopup(props.rideRequest.dropOffLocation)
      .openPopup()

  // DropOff marker
  L.marker([dropoffLat, dropoffLon], {icon: mapPinIcon})
      .addTo(map.value)
      .bindPopup(props.rideRequest.pickupLocation)
      .openPopup()

  // Route line
  L.polyline(
      [
        [pickupLat, pickupLon],
        [dropoffLat, dropoffLon]
      ],
      {
        color: "#00c950",
        weight: 5,
      }
  ).addTo(map.value)

  const bounds = L.latLngBounds([
    [pickupLat, pickupLon],
    [dropoffLat, dropoffLon]
  ])

  map.value.fitBounds(bounds, {padding: [50, 50]})
}

onMounted(() => {
  initializeMap()
})


watch(
    () => props.rideRequest,
    async () => {
      await nextTick()
      initializeMap()
    },
    {deep: true}
)


onBeforeUnmount(() => {
  if (map.value) {
    map.value.remove()
    map.value = null
  }
})
</script>

<template>
  <div class="flex-1 relative bg-gray-800">
    <div ref="driverMapContainer" class="w-full h-full"></div>

    <div
        v-if="rideRequest?.trip"
        class="absolute top-6 right-6 bg-gray-900/90 backdrop-blur rounded-lg p-4 max-w-sm"
    >
      <p class="text-xs text-blue-400 uppercase font-semibold">
        Live Tracking
      </p>
      <p class="text-white font-medium mt-2">
        Driver is approaching {{ rideRequest.dropOffLocation }}
      </p>
    </div>
  </div>
</template>

<style scoped>
:deep(#map) {
  filter: invert(0.9) hue-rotate(200deg);
}
</style>
