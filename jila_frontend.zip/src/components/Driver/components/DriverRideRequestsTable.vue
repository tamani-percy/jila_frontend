<script setup lang="ts">
import {h, onMounted, type Ref, ref, resolveComponent, watch} from "vue";
import type {TableColumn} from "@nuxt/ui/components/Table.vue";
import {dateTimeFormatter} from "@/utils/DateTimeFormatter.ts";
import type {AccordionItem} from '@nuxt/ui'
import {getAllRideRequests} from "@/api/services/RideRequestService.ts";
import {useDriverStore} from "@/stores/driverStore.ts";
import {useVehicleStore} from "@/stores/vehicleStore.ts";
import {createTrip} from "@/api/services/TripService.ts";
import {Client} from "@stomp/stompjs";

const props = defineProps<{
  rideRequestTrigger: number
}>()

const emits = defineEmits<{
  acceptRide: [value: boolean]
}>()

watch(
    () => props.rideRequestTrigger,
    () => {
      onFetchRideRequestByStatus()
    }
)

let tripSubscription: any = null
const stompClient = ref<Client | null>(null)
const activeTrip = ref<any | null>(null)
const lastUpdateTime = ref<string>('Never')

const rideRequests: Ref<RideRequestResponse[] | undefined> = ref<RideRequestResponse[] | undefined>([])
const isRideRequestsLoading: Ref<boolean> = ref<boolean>(false)

const toast = useToast()
const driverStore = useDriverStore()
const vehicleStore = useVehicleStore()

const UButton = resolveComponent('UButton')

const isCancelRideRequestLoading: Ref<boolean> = ref<boolean>(false)
const onFetchRideRequestByStatus = async () => {
  try {
    isRideRequestsLoading.value = true
    const res = await getAllRideRequests()
    rideRequests.value = res.filter((request => request.rideRequestStatus === "AVAILABLE"))
  } catch (e) {
    toast.add({
      title: 'Failed',
      description: 'Failed to fetch ride requests.',
      color: 'error'
    })
  } finally {
    isRideRequestsLoading.value = false
  }
}

onMounted(() => {
  onFetchRideRequestByStatus()
})

const columns: TableColumn<RideRequestResponse>[] = [
  {
    accessorKey: 'id',
    header: '',
    cell: ({row}) => {
      return h(UButton, {
            loading: isCancelRideRequestLoading.value,
            color: 'info', variant: 'subtle', onClick() {
              acceptRide(row.getValue("id"))
            }
          }, () =>
              "ACCEPT RIDE"
      )
    }
  },
  {
    accessorKey: 'pickupLocation',
    header: 'Pickup Location',
    cell: ({row}) => `${row.getValue('pickupLocation')}`
  },
  {
    accessorKey: 'dropOffLocation',
    header: 'Drop Off Location',
    cell: ({row}) => `${row.getValue('dropOffLocation')}`
  },

  {
    accessorKey: 'requestedAt',
    header: 'Requested At',
    cell: ({row}) => `${dateTimeFormatter(row.getValue('requestedAt'))}`
  },
]

const items = [
  {
    label: 'Ride Requests',
    icon: 'i-lucide-car'
  },
] satisfies AccordionItem[]

const acceptRide = async (rideRequestId: number) => {
  try {
    const tripRequest: TripRequest = {
      driverId: driverStore?.getDriverData?.id,
      rideRequestId: rideRequestId,
      vehicleId: vehicleStore?.getVehicleData?.id,
      fareTotal: Math.random(),
    }

    const response = await createTrip(tripRequest)


    rideRequests.value = rideRequests.value.filter(
        r => r.id !== rideRequestId
    )

    emits('acceptRide', true)

    subscribeToTrip(activeTrip.value.id)
    toast.add({title: 'Success', description: 'Accepted ride. Ride is now a trip.', color: 'success'})

  } catch (err) {
    toast.add({title: 'Failed', description: 'Failed to accept ride.', color: 'error'})
  }
}

const subscribeToTrip = (tripId: number) => {

  if (!stompClient.value || !stompClient.value.connected) {
    console.warn("WebSocket not connected yet")
    return
  }

  if (tripSubscription) {
    tripSubscription.unsubscribe()
  }

  const topic = `/topic/trip/${tripId}`

  tripSubscription = stompClient.value.subscribe(topic, (message) => {
    try {
      const update = JSON.parse(message.body)

      activeTrip.value = {
        ...activeTrip.value,
        ...update
      }

      lastUpdateTime.value = new Date().toLocaleTimeString()

      if (update.tripStatus === 'COMPLETED') {
        setTimeout(() => {
          activeTrip.value = null
          if (tripSubscription) {
            tripSubscription.unsubscribe()
          }
        }, 2000)
      }

    } catch (e) {
      console.error("Error parsing trip update", e)
    }
  })
}
</script>

<template>
  <UAccordion :items="items">
    <template #content="{ item }">
      <UCard variant="subtle">
        <UTable sticky :data="rideRequests" class="flex-1 max-h-[312px]" :loading="isRideRequestsLoading"
                :columns="columns"/>
      </UCard>
    </template>
  </UAccordion>

</template>

<style scoped>

</style>