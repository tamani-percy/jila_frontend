<script setup lang="ts">
defineProps<{
  trip: TripResponse
}>()
</script>

<template>
  <div class="w-96 bg-gray-100 p-4 border-l h-full">
    <div class="bg-white shadow rounded p-4 space-y-3">

      <h2 class="text-lg font-bold">
        Trip #{{ trip.id }}
      </h2>

      <div>
        <p class="text-sm text-gray-500">Status</p>
        <p class="font-semibold">{{ trip.tripStatus }}</p>
      </div>

      <div>
        <p class="text-sm text-gray-500">Distance</p>
        <p class="font-semibold">{{ trip.distance }} km</p>
      </div>

      <div>
        <p class="text-sm text-gray-500">Fare</p>
        <p class="font-semibold">ZMW {{ trip.fareTotal }}</p>
      </div>

      <div>
        <p class="text-sm text-gray-500">Vehicle</p>
        <p>
          {{ trip.vehicle?.plateNumber }} -
          {{ trip.vehicle?.model }}
        </p>
      </div>

      <div>
        <p class="text-sm text-gray-500">Started</p>
        <p>{{ trip.startedAt }}</p>
      </div>

      <div v-if="trip.endedAt">
        <p class="text-sm text-gray-500">Ended</p>
        <p>{{ trip.endedAt }}</p>
      </div>

    </div>
  </div>
</template>
