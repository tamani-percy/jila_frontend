<script setup lang="ts">
defineProps<{
  rideRequest: RideRequestResponse
  isCreateRideRequestLoading: boolean
  isCancelRideRequestLoading: boolean
}>()

defineEmits(['cancel'])
</script>

<template>
  <div class="w-full text-white space-y-6">
    <div class="space-y-4">
      <div class="flex items-start gap-3">
        <UIcon name="i-lucide-circle" class="size-5 text-blue-500 mt-1"/>
        <div>
          <p class="text-xs text-gray-400 uppercase">PICKUP</p>
          <p class="text-sm font-medium text-black">{{ rideRequest.pickupLocation }}</p>
        </div>
      </div>

      <div class="flex items-start gap-3">
        <UIcon name="i-lucide-circle" class="size-5 text-blue-500 mt-1 bg-blue-500 rounded-full"/>
        <div>
          <p class="text-xs text-gray-400 uppercase">DROP OFF</p>
          <p class="text-sm font-medium text-black">{{ rideRequest.dropOffLocation }}</p>
        </div>
      </div>
    </div>

    <!-- Waiting State -->
    <div v-if="rideRequest.trip">
      {{ rideRequest?.trip}}
    </div>
    <div v-else>
      <UAlert
          color="info"
          title="Heads up!"
          description="Waiting for driver to accept your request."
          icon="i-lucide-car"
      />
    </div>

    <UButton
        @click="$emit('cancel')"
        :loading="isCreateRideRequestLoading"
        :disabled="isCancelRideRequestLoading"
        class="w-fit"
        color="error"
        variant="outline"
        label="CANCEL RIDE REQUEST"
        size="lg"
    />
  </div>
</template>
