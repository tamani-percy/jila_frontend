<template>
  <div class="flex h-full w-full h-screen  bg-gray-900 rounded-lg">
    <UCard class="w-1/4 h-full overflow-y-auto" variant="outline">
      <template #header>
        <h1 class="inline-flex items-center font-bold text-xl">
          <UIcon
              name="i-lucide-car-front"
              class="size-8 text-white bg-[#135bec] p-1 rounded-lg"
          />
          &nbsp; Jila
        </h1>
      </template>
      <Transition name="fade">
        <DriverMapContainer
            v-if="rideRequestStore.isRideRequestCreated"
            :rideRequest="rideRequestStore.rideRequest"
        />
      </Transition>
      <template #footer>
        <DriverRideRequestsTable/>
      </template>
    </UCard>

  </div>
  <CreateDriverModal :isCreateDriverModalOpen="!isSetupComplete"/>
</template>

<script setup lang="ts">
import {computed} from 'vue'
import {useDriverStore} from "@/stores/driverStore"
import {useVehicleStore} from "@/stores/vehicleStore"
import {useRideRequestStore} from "@/stores/rideRequestStore.ts";

const driverStore = useDriverStore()
const rideRequestStore = useRideRequestStore()
const vehicleStore = useVehicleStore()

const isSetupComplete = computed(() => {
  return driverStore.isDriverAvailable &&
      vehicleStore.isVehicleAvailable
})
</script>
